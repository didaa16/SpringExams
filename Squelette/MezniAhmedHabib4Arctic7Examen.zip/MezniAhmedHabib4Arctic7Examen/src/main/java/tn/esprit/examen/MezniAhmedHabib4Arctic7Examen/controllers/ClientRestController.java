package tn.esprit.examen.MezniAhmedHabib4Arctic7Examen.controllers;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import tn.esprit.examen.MezniAhmedHabib4Arctic7Examen.entities.Client;
import tn.esprit.examen.MezniAhmedHabib4Arctic7Examen.services.IServices;

@RequiredArgsConstructor
@RequestMapping("examen")
@RestController
public class ClientRestController {
    private final IServices services;

    @PostMapping("/add")
    public Client add(@RequestBody Client client){
        return  services.add(client);
    }

}
