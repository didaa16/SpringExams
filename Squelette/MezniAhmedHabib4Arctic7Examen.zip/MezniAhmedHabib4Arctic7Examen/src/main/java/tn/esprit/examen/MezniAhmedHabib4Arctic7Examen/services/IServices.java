package tn.esprit.examen.MezniAhmedHabib4Arctic7Examen.services;

import tn.esprit.examen.MezniAhmedHabib4Arctic7Examen.entities.Client;

public interface IServices {
    Client add(Client client);
    //void test();
}
